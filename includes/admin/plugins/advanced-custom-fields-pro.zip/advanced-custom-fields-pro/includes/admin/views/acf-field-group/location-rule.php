<?php
/**
 * @package ACF
 * @author  WP Engine
 *
 * © 2026 Advanced Custom Fields (ACF®). All rights reserved.
 * "ACF" is a trademark of WP Engine.
 * Licensed under the GNU General Public License v2 or later.
 * https://www.gnu.org/licenses/gpl-2.0.html
 */

// vars
$prefix = 'acf_field_group[location][' . $rule['group'] . '][' . $rule['id'] . ']';
?>
<tr data-id="<?php echo esc_attr( $rule['id'] ); ?>">
	<td class="param">
		<?php

		// vars
		$choices = acf_get_location_rule_types();

		// array
		if ( is_array( $choices ) ) {
			acf_render_field(
				array(
					'type'    => 'select',
					'name'    => 'param',
					'prefix'  => $prefix,
					'value'   => $rule['param'],
					'choices' => $choices,
					'class'   => 'refresh-location-rule',
				)
			);
		}

		?>
	</td>
	<td class="operator">
		<?php

		// vars
		$choices = acf_get_location_rule_operators( $rule );


		// array
		if ( is_array( $choices ) ) {
			acf_render_field(
				array(
					'type'    => 'select',
					'name'    => 'operator',
					'prefix'  => $prefix,
					'value'   => $rule['operator'],
					'choices' => $choices,
				)
			);

			// custom
		} else {
			echo acf_esc_html( $choices );
		}

		?>
	</td>
	<td class="value">
		<?php

		// vars
		$choices = acf_get_location_rule_values( $rule );


		// array
		if ( is_array( $choices ) ) {
			acf_render_field(
				array(
					'type'    => 'select',
					'name'    => 'value',
					'class'   => 'location-rule-value',
					'prefix'  => $prefix,
					'value'   => $rule['value'],
					'choices' => $choices,
				)
			);

			// custom
		} else {
			echo acf_esc_html( $choices );
		}

		?>
	</td>
	<td class="add">
		<a href="#" class="button add-location-rule"><?php esc_html_e( 'and', 'acf' ); ?></a>
	</td>
	<td class="remove">
		<a href="#" class="acf-icon -minus remove-location-rule"></a>
	</td>
</tr>
